import { useEffect, useState } from "react";
import { DisplayTimer } from "./components/DisplayTimer";
import { TimerInputs } from "./components/TimerInputs";
import { TimerActions } from "./components/TimerActions";
import "./styles.css";

export default function App() {
  const [timer, setTimer] = useState();
  const [minutes, setMinutes] = useState(0);
  const [seconds, setSeconds] = useState(0);

  const startTimer = () => {
    if (timer) {
      clearInterval(timer);
    }
    const newTimer = setInterval(() => {
      setSeconds((prevSeconds) => prevSeconds - 1);
    }, 1000);

    setTimer(newTimer);
  };

  const pauseTimer = () => {};

  useEffect(() => {
    if (minutes === 0) {
      clearInterval(timer);
    }
    if (seconds === 0 && timer) {
      setMinutes((prevMinutes) => prevMinutes - 1);
      setSeconds(59);
    }
  }, [seconds, minutes, timer]);

  return (
    <div className="App">
      <DisplayTimer minutes={minutes} seconds={seconds} />
      <TimerInputs minutesHandler={setMinutes} secondsHandler={setSeconds} />
      <TimerActions startTimer={startTimer} pauseTimer={pauseTimer} />
    </div>
  );
}

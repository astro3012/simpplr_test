import React from "react";

type TimerInputsPropsType = {
  minutesHandler: React.Dispatch<(prevState: number) => number>;
  secondsHandler: React.Dispatch<(prevState: number) => number>;
};

export const TimerInputs: React.FC<TimerInputsPropsType> = (props) => {
  const { minutesHandler, secondsHandler } = props;

  const onSecondsChange = (event) => {
    secondsHandler(event.target.value);
  };
  const onMinutesChange = (event) => {
    minutesHandler(event.target.value);
  };
  return (
    <>
      <div>This is timer input </div>
      <div>
        <input placeholder={"minutes"} onChange={onMinutesChange} />
        <input placeholder={"seconds"} onChange={onSecondsChange} />
      </div>
    </>
  );
};

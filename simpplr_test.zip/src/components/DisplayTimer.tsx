import React from "react";

type DisplayTimerPropsType = {
  minutes: number;
  seconds: number;
};

export const DisplayTimer: React.FC<DisplayTimerPropsType> = (props) => {
  const { minutes, seconds } = props;
  return <div>{`${minutes} : ${seconds}`}</div>;
};

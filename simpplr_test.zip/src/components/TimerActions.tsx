import React from "react";

type TimerActionsPropsType = {
  startTimer: () => void;
  pauseTimer: () => void;
};

export const TimerActions: React.FC<TimerActionsPropsType> = (props) => {
  const { startTimer, pauseTimer } = props;

  return (
    <div>
      <div>
        <button onClick={startTimer}>START</button>
      </div>
      <div>
        <button onClick={pauseTimer}>PAUSE</button>
      </div>
    </div>
  );
};
